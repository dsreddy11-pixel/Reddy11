package com.glassmusic.app

import android.Manifest
import android.content.ContentUris
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import java.util.concurrent.TimeUnit

private data class Song(val id: Long, val title: String, val artist: String, val uri: Uri, val duration: Long)

class MainActivity : ComponentActivity() {
    private lateinit var player: ExoPlayer
    private var songsState = mutableStateOf<List<Song>>(emptyList())
    private var permissionGranted = mutableStateOf(false)
    private var playingState = mutableStateOf(false)

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        permissionGranted.value = granted
        if (granted) loadSongs()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playingState.value = isPlaying }
        })
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        permissionGranted.value = ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED
        if (permissionGranted.value) loadSongs()
        setContent {
            GlassMusicScreen(
                songs = songsState.value,
                hasPermission = permissionGranted.value,
                onRequestPermission = { permissionLauncher.launch(permission) },
                onPlay = { song ->
                    val index = songsState.value.indexOf(song).coerceAtLeast(0)
                    player.setMediaItems(songsState.value.map { MediaItem.fromUri(it.uri) }, index, 0)
                    player.prepare(); player.play()
                },
                onYoutube = { openYoutubeMusic() },
                onToggle = { if (player.isPlaying) player.pause() else player.play() },
                isPlaying = playingState.value
            )
        }
    }

    private fun loadSongs() {
        val list = mutableListOf<Song>()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        contentResolver.query(collection, projection, selection, null, "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC")?.use { cursor ->
            val idCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val titleCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
            val artistCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
            val durationCol = cursor.getColumnIndexOrThrow(MediaStore.Audio.Media.DURATION)
            while (cursor.moveToNext()) {
                val id = cursor.getLong(idCol)
                list += Song(id, cursor.getString(titleCol) ?: "Unknown title", cursor.getString(artistCol) ?: "Unknown artist", ContentUris.withAppendedId(collection, id), cursor.getLong(durationCol))
            }
        }
        songsState.value = list
    }

    private fun openYoutubeMusic() {
        val intent = packageManager.getLaunchIntentForPackage("com.google.android.apps.youtube.music")
            ?: android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com"))
        try { startActivity(intent) } catch (_: Exception) {
            startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com")))
        }
    }

    override fun onDestroy() { player.release(); super.onDestroy() }
}

@Composable
private fun GlassMusicScreen(
    songs: List<Song>, hasPermission: Boolean, onRequestPermission: () -> Unit,
    onPlay: (Song) -> Unit, onYoutube: () -> Unit, onToggle: () -> Unit, isPlaying: Boolean
) {
    val bg = Brush.linearGradient(listOf(Color(0xFF101426), Color(0xFF25234B), Color(0xFF090D18)))
    var selectedTab by remember { mutableStateOf("Library") }
    var search by remember { mutableStateOf("") }
    var currentTitle by remember { mutableStateOf("Choose a song") }
    MaterialTheme(colorScheme = darkColorScheme(primary = Color(0xFFB9A7FF), background = Color(0xFF101426))) {
        Box(Modifier.fillMaxSize().background(bg)) {
            Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 20.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column {
                        Text("GLASSMUSIC", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                        Text("Your sound. Your space.", color = Color(0xFFB9B8D2), fontSize = 12.sp)
                    }
                    Box(Modifier.size(42.dp).background(Color.White.copy(alpha = .12f), CircleShape), contentAlignment = Alignment.Center) { Text("♪", color = Color.White, fontSize = 25.sp) }
                }
                Spacer(Modifier.height(24.dp))
                GlassPanel(Modifier.fillMaxWidth()) {
                    Text("Good evening", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.SemiBold)
                    Text("A little music makes everything better.", color = Color(0xFFCECAE5), fontSize = 13.sp)
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        SourceButton("♫  Offline library", Modifier.weight(1f)) { selectedTab = "Library" }
                        SourceButton("▶  YouTube Music", Modifier.weight(1f)) { onYoutube() }
                    }
                }
                Spacer(Modifier.height(18.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    listOf("Library", "Playlists").forEach { tab ->
                        Box(Modifier.background(if (selectedTab == tab) Color.White.copy(.18f) else Color.White.copy(.07f), RoundedCornerShape(50)).clickable { selectedTab = tab }.padding(horizontal = 18.dp, vertical = 9.dp)) {
                            Text(tab, color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                OutlinedTextField(value = search, onValueChange = { search = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Search your songs", color = Color(0xFF9D9AB7)) }, singleLine = true, shape = RoundedCornerShape(18.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.White.copy(.14f), focusedBorderColor = Color(0xFFB9A7FF), unfocusedTextColor = Color.White, focusedTextColor = Color.White))
                Spacer(Modifier.height(10.dp))
                if (!hasPermission) {
                    GlassPanel(Modifier.fillMaxWidth()) {
                        Text("Find music on your phone", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Allow audio access to show your local songs.", color = Color(0xFFCECAE5), fontSize = 13.sp)
                        Spacer(Modifier.height(10.dp))
                        Button(onClick = onRequestPermission) { Text("Allow access") }
                    }
                } else if (songs.isEmpty()) {
                    GlassPanel(Modifier.fillMaxWidth()) {
                        Text("Your library is waiting", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("No local music was found. Add audio files to your phone, then reopen GlassMusic.", color = Color(0xFFCECAE5), fontSize = 13.sp)
                    }
                } else {
                    Text("YOUR MUSIC  ·  ${songs.size} TRACKS", color = Color(0xFFB9B8D2), fontSize = 11.sp, letterSpacing = 1.5.sp)
                    Spacer(Modifier.height(6.dp))
                    LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(songs.filter { it.title.contains(search, true) || it.artist.contains(search, true) }) { song ->
                            GlassPanel(Modifier.fillMaxWidth().clickable { currentTitle = song.title; onPlay(song) }) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(42.dp).background(Brush.linearGradient(listOf(Color(0xFF7667C8), Color(0xFF3D8A9E))), RoundedCornerShape(12.dp)), contentAlignment = Alignment.Center) { Text("♫", color = Color.White, fontSize = 22.sp) }
                                    Column(Modifier.weight(1f).padding(start = 12.dp)) {
                                        Text(song.title, color = Color.White, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                        Text(song.artist, color = Color(0xFFB9B8D2), fontSize = 12.sp, maxLines = 1)
                                    }
                                    Text("▶", color = Color(0xFFD4C9FF), fontSize = 17.sp)
                                }
                            }
                        }
                    }
                }
                GlassPanel(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(42.dp).background(Color(0xFF6B5BAA), RoundedCornerShape(11.dp)), contentAlignment = Alignment.Center) { Text("♫", color = Color.White, fontSize = 22.sp) }
                        Column(Modifier.weight(1f).padding(start = 12.dp)) {
                            Text(currentTitle, color = Color.White, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("Now playing on this device", color = Color(0xFFB9B8D2), fontSize = 11.sp)
                        }
                        Text(if (isPlaying) "Ⅱ" else "▶", color = Color.White, fontSize = 23.sp, modifier = Modifier.clickable { onToggle() }.padding(8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun GlassPanel(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.background(Color.White.copy(alpha = .095f), RoundedCornerShape(24.dp)).padding(16.dp), content = content)
}

@Composable
private fun SourceButton(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(modifier.background(Color.White.copy(.14f), RoundedCornerShape(14.dp)).clickable { onClick() }.padding(vertical = 12.dp, horizontal = 10.dp), contentAlignment = Alignment.Center) {
        Text(label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Medium)
    }
}
